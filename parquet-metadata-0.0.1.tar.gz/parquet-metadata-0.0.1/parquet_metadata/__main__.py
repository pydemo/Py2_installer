from .parquet_metadata import main
main()
